# This is my SpaceRock Class

class SpaceRock(object):
    
    def __init__(self, name=None, ab_mag=None, albedo=None):
        self.name = name
        self.ab_mag = ab_mag
        self.albedo = albedo
        
    def diameter(self):
        result = (1329.0 / np.sqrt(self.albedo)) * (10 ** (-0.2 * self.ab_mag))
        return result * u.km