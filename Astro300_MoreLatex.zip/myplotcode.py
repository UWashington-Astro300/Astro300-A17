fig, ax = plt.subplots(1,1) 
fig.set_size_inches(15,10)

fig.tight_layout()

BV = T['Bmag'] - T['Vmag']
V = T['Vmag']

ax.set_xlim(-0.25,1.5)
ax.set_ylim(12,19)

ax.set_aspect(1/6) 
ax.invert_yaxis() 
ax.set_xlabel("B-V")
ax.set_ylabel("V")

ax.set_title("M15 Color Magnitude Diagram")

ax.plot(BV,V,color="b",marker="o",linestyle="None",markersize=5)

ax.text(-0.1, 13.5, 'Horizontal Giant Branch', color='r', fontsize=24)
ax.vlines(0.3, 13.7, 15.3, color='r', linewidth=3)

mask_color = np.where((V < 16.25) & (BV < 0.55))     

ax.plot(BV[mask_color], V[mask_color],color="r",marker="o",linestyle="None",markersize=4, alpha=0.5);